// Converted from SnB_UI_C/Search_PID_201_500.c on Mon May  3 07:15:55 2021
/*-----------------------------------------------------------------------------
Name: Search_PID_201_500
Recorded By: Manish
Date of recording: 08/03/2018 02:04:04
Flow details:
Build details: 4.1.11 (build# 216)
Modification History:
-----------------------------------------------------------------------------*/


package com.cavisson.scripts.SNB_UI_Java;
import pacJnvmApi.NSApi;



public class Search_PID_201_500 implements NsFlow
{
	public int execute(NSApi nsApi) throws Exception
	{
		int status = 0;
		nsApi.ns_advance_param("FP_PID_201_500");

		nsApi.ns_start_transaction("Search_PID_201_500");
		nsApi.ns_web_url("PDP_search_sku_500",
				"URL=https://{Host}/search.jsp?submit-search=&search={FP_PID_201_500}",
				"HEADER=Host:www-cstressrel-green.kohlsecommerce.com",
				"HEADER=Accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
				"HEADER=Upgrade-Insecure-Requests:1",
				"HEADER=Referer:https://www-cstressrel-green.kohlsecommerce.com/",
				"HEADER=User-Agent:Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36",
				"HEADER=Accept-Encoding:gzip, deflate",
				"HEADER=Accept-Language:en-us",
				"COOKIE=_abck;bm_sz;SL_Cookie;AKA_A2"
				);

		if (nsApi.ns_get_int_val("pid_201_500_notFound") > 0) 
		{ 
			nsApi.ns_end_transaction_as("Search_PID_201_500", 0, "Search_PID_201_500_PDPNotFound");

		}
		else if(nsApi.ns_eval_string("{SP_skuCode}").equals(""))
			nsApi.ns_end_transaction_as("Search_PID_201_500", 0, "Search_PID_201_500_CatalogPage");
		else 
			nsApi.ns_end_transaction("Search_PID_201_500", NS_AUTO_STATUS);


		nsApi.ns_page_think_time(0);
		return status;
	}

}
