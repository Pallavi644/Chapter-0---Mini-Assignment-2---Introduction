// Converted from SnB_UI_C/BrowsetoCatalogPage.c on Mon May  3 07:15:55 2021
/*-----------------------------------------------------------------------------
Name: BrowsetoCatalogPage
Recorded By: Manish
Date of recording: 07/10/2018 04:15:29
Flow details:
Build details: 4.1.10 (build# 34)
Modification History:
-----------------------------------------------------------------------------*/

package com.cavisson.scripts.SNB_UI_Java;
import pacJnvmApi.NSApi;


public class BrowsetoCatalogPage implements NsFlow
{
	public int execute(NSApi nsApi) throws Exception
	{
		System.out.println("\n\n\n************Amiya!, This is Entry to BrowsCatalog*********************\n\n\n");
		int status = 0;
		nsApi.ns_start_transaction("CatalogPage");
		nsApi.ns_web_url("CatalogPage",
				"URL=https://{Host}{SP_CatalogUrl}",
				"HEADER=Host:www-qa02.kohlsecommerce.com",
				"HEADER=Accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
				"HEADER=Upgrade-Insecure-Requests:1",
				"HEADER=Referer:https://www-qa02.kohlsecommerce.com/sale-event/mens-clothing.jsp?cc=mens-TN1.0-S-men",
				"HEADER=User-Agent:Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36",
				"HEADER=Accept-Encoding:gzip, deflate",
				"HEADER=Accept-Language:en-us",
				"COOKIE=store_location;_abck;SL_Cookie;AKA_A2;bm_sz;mosaic;X-SESSIONID;akacd_www-kohls-com-mosaic-p2;check;kohls_wcs_cookie;kohls_klbd_cookie;dcroute;AMCVS_F0EF5E09512D2CD20A490D4D%40AdobeOrg;s_cc;namogooTest;AAMC_kohls_0;fltk;aam_uuid;btpdb.QF4SXwN.c2lnbmFsIDFzdCBwYXJ0eSBpZA;SignalSpring2016;SignalSpring2018;cto_lwid;btpdb.4DPyaxM.dGZjLjYyMTAxMDM;btpdb.4DPyaxM.dGZjLjYyMTAxMTA;btpdb.4DPyaxM.dGZjLjYyMDYyMTU;btpdb.4DPyaxM.dGZjLjYyMDYyMDU;btpdb.4DPyaxM.Y3VzdG9tZXIgfCBzaWduYWwgMXN0IHBhcnR5IGlkIC0gc2Vzc2lvbg;btpdb.4DPyaxM.Y3VzdG9tZXIgfCBzaWduYWwgMXN0IHBhcnR5IGlkIC0gMzY1IGRheXM;staleStorage;__gads;_ga;_gid;IR_gbd;IR_PI;btpdb.4DPyaxM.X2J0X2djbXNfaWQ;ndcd;s_stv;VisitorId;K_favstore;DYN_USER_ID;VisitorUsaFullName;LoginSuccess;VisitorBagSession;VisitorBagTotals;isPreQualEligible;_scid;CRTOABE;hl_p;_sctr;fsr.s;SignalUniversalID;CavNV;TS01ada7dd;DCRouteS;productnum;gpv_v9;fsr.a;AMCV_F0EF5E09512D2CD20A490D4D%40AdobeOrg;mbox;_gat;rr_rcs;CavSF;IR_5349;akavpau_www;correlation-id;X-PROFILEID;RT;s_sq;kls_p;CavNVC"
				);


		if(nsApi.ns_get_int_val("SP_totalRecordsCount") > 1)
		{
			nsApi.ns_end_transaction("CatalogPage", NS_AUTO_STATUS);
			
		}
		else
			nsApi.ns_end_transaction_as("CatalogPage", 0, "CatalogPage_ZeroProduct"); 
		

		nsApi.ns_advance_param("RN_Number");
		nsApi.ns_page_think_time(0);
		System.out.println("\n\n\n************Amiya!, This is Exit to BrowsCatalog*********************\n\n\n");
		return status;
	}

}
