/*-----------------------------------------------------------------------------
    Name: runlogic 
    runlogic details:
    Modification History:
-----------------------------------------------------------------------------*/

package com.cavisson.scripts.SNB_UI_Java;

import pacJnvmApi.NSApi;

public class runlogic
{

    // Note: Following extern declaration is used to find the list of used flows. Do not delete/edit it
    //Start - List of used flows in the runlogic
    //Initialise the SetCookies class
    SetCookies SetCookiesObj = new SetCookies();
    //Initialise the BrowsetoCatalogPage class
    BrowsetoCatalogPage BrowsetoCatalogPageObj = new BrowsetoCatalogPage();
    //Initialise the CatalogPagination class
    CatalogPagination CatalogPaginationObj = new CatalogPagination();
    //Initialise the CatalogSortBy class
    CatalogSortBy CatalogSortByObj = new CatalogSortBy();
    //Initialise the CatalogRefines class
    CatalogRefines CatalogRefinesObj = new CatalogRefines();
    //Initialise the CatalogView120items class
    CatalogView120items CatalogView120itemsObj = new CatalogView120items();
    //Initialise the Skip_Functionality class
    Skip_Functionality Skip_FunctionalityObj = new Skip_Functionality();
    //Initialise the CatalogPDP class
    CatalogPDP CatalogPDPObj = new CatalogPDP();
    //Initialise the Availability_pickup class
    Availability_pickup Availability_pickupObj = new Availability_pickup();
    //Initialise the SearchByKeyword class
    SearchByKeyword SearchByKeywordObj = new SearchByKeyword();
    //Initialise the SearchPDP class
    SearchPDP SearchPDPObj = new SearchPDP();
    //Initialise the Search_PID_1_50 class
    Search_PID_1_50 Search_PID_1_50Obj = new Search_PID_1_50();
    //Initialise the Search_PID_51_100 class
    Search_PID_51_100 Search_PID_51_100Obj = new Search_PID_51_100();
    //Initialise the Search_PID_101_200 class
    Search_PID_101_200 Search_PID_101_200Obj = new Search_PID_101_200();
    //Initialise the Search_PID_501_1000 class
    Search_PID_501_1000 Search_PID_501_1000Obj = new Search_PID_501_1000();
    //Initialise the Search_PID_1000 class
    Search_PID_1000 Search_PID_1000Obj = new Search_PID_1000();
    //Initialise the Search_PID_201_500 class
    Search_PID_201_500 Search_PID_201_500Obj = new Search_PID_201_500();
    //Initialise the TypeHeadSolr class
    TypeAheadsolr TypeAheadsolrObj = new TypeAheadsolr();
    //Initialise the PDPOnly class
    PDPOnly PDPOnlyObj = new PDPOnly();
    //End - List of used flows in the runlogic

    public void execute(NSApi nsApi) throws Exception
    {
        //Logging
        int initStatus = init_script.execute(nsApi);

        //Executing percent block - Start
        int Startpercent = nsApi.ns_get_random_number_int(1, 10000);

        //"Percentage random number for block - Start = %d", Startpercent

        if(Startpercent <= 10000)
        {

                //Executing sequence block - Users (pct value = 100.0%)
                //Executing flow - SetCookies
                SetCookiesObj.execute(nsApi);

                    //Executing percent block - BrowseNSearch_AddtoBag (pct value = 100.0%)
                    int BrowseNSearch_AddtoBagpercent = nsApi.ns_get_random_number_int(1, 10000);

                    //"Percentage random number for block - BrowseNSearch_AddtoBag = %d", BrowseNSearch_AddtoBagpercent

                    if(BrowseNSearch_AddtoBagpercent <= 10000)
                    {

                            //Executing percent block - BrowsingFlows (pct value = 100.0%)
                            int BrowsingFlowspercent = nsApi.ns_get_random_number_int(1, 10000);

                            //"Percentage random number for block - BrowsingFlows = %d", BrowsingFlowspercent

                            if(BrowsingFlowspercent <= 3000)
                            {

                                    //Executing sequence block - BrowseToPDP (pct value = 30.0%)
                                    //Executing flow - BrowsetoCatalogPage
                                    BrowsetoCatalogPageObj.execute(nsApi);

                                        //Executing sequence block - RefineCatalog (pct value = 30.0%)

                                            //Executing percent block - RefineOperation (pct value = 30.0%)
                                            int RefineOperationpercent = nsApi.ns_get_random_number_int(1, 10000);

                                            //"Percentage random number for block - RefineOperation = %d", RefineOperationpercent

                                            if(RefineOperationpercent <= 1800)
                                            {
                                                CatalogPaginationObj.execute(nsApi);
                                            }
                                            else if(RefineOperationpercent <= 5800)
                                            {
                                                CatalogSortByObj.execute(nsApi);
                                            }
                                            else if(RefineOperationpercent <= 9800)
                                            {
                                                CatalogRefinesObj.execute(nsApi);
                                            }
                                            else if(RefineOperationpercent <= 9900)
                                            {
                                                CatalogView120itemsObj.execute(nsApi);
                                            }
                                            else if(RefineOperationpercent <= 10000)
                                            {
                                                Skip_FunctionalityObj.execute(nsApi);
                                            }
                                    //Executing flow - CatalogPDP
                                    CatalogPDPObj.execute(nsApi);
                                    //Executing flow - Availability_pickup
                                    Availability_pickupObj.execute(nsApi);
                            }
                            else if(BrowsingFlowspercent <= 6000)
                            {

                                    //Executing sequence block - SearchByKeyword_Flow (pct value = 30.0%)
                                    //Executing flow - SearchByKeyword
                                    SearchByKeywordObj.execute(nsApi);
                                    //Executing flow - SearchPDP
                                    SearchPDPObj.execute(nsApi);
                            }
                            else if(BrowsingFlowspercent <= 7000)
                            {

                                    //Executing sequence block - SearchByPIDS (pct value = 10.0%)

                                        //Executing percent block - SearchByPID (pct value = 10.0%)
                                        int SearchByPIDpercent = nsApi.ns_get_random_number_int(1, 10000);

                                        //"Percentage random number for block - SearchByPID = %d", SearchByPIDpercent

                                        if(SearchByPIDpercent <= 8000)
                                        {
                                            Search_PID_1_50Obj.execute(nsApi);
                                        }
                                        else if(SearchByPIDpercent <= 9500)
                                        {
                                            Search_PID_51_100Obj.execute(nsApi);
                                        }
                                        else if(SearchByPIDpercent <= 9800)
                                        {
                                            Search_PID_101_200Obj.execute(nsApi);
                                        }
                                        else if(SearchByPIDpercent <= 9900)
                                        {
                                            Search_PID_501_1000Obj.execute(nsApi);
                                        }
                                        else if(SearchByPIDpercent <= 10000)
                                        {
                                            Search_PID_1000Obj.execute(nsApi);
                                        }
                                        else if(SearchByPIDpercent <= 10000)
                                        {
                                            Search_PID_201_500Obj.execute(nsApi);
                                        }
                            }
                            else if(BrowsingFlowspercent <= 7500)
                            {

                                    //Executing sequence block - TypeAhead (pct value = 5.0%)
                                    //Executing flow - TypeAheadsolr
                                    TypeAheadsolrObj.execute(nsApi);
                            }
                            else if(BrowsingFlowspercent <= 10000)
                            {
                                PDPOnlyObj.execute(nsApi);
                            }
                    }
        }

        //logging
        nsApi.ns_end_session();
    }

}


